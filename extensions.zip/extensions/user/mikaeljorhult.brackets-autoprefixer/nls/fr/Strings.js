define( {
	// Generic.
	OK:     "OK",
	CANCEL: "Annuler",
	RESET:  "Réinitialiser",
	
	// Menu.
	MENU_ON_SAVE:   "Auto prefixer lors de la sauvegarde",
	MENU_SELECTION: "Auto prefix la selection",
	MENU_SETTINGS:  "Paramètres Autoprefixer...",
	
	// Settings dialog.
	SETTINGS_TITLE:          "Paramètres Autoprefixer",
	SETTINGS_VISUAL_CASCADE: "Cascade visuelle",
	SETTINGS_BROWSERS:       "Navigateurs"
} );