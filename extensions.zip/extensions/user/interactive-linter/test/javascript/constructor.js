var str = new String("hello"),
    num = new Number(10),
    bool = new Boolean(false),
    math = new Math(),
    json = new JSON({ myProp: 10 });