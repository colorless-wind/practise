define(function(){
    "use strict";

    var model = {
        name: "W041"
    };


    function run(){
        if ( model.name   !=   '' ) {
            console.log("Not Equal");
        }
    }

    run();
});

