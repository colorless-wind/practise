// Only properties should be deleted.
if (delete  bla  ) {
    x = 2;
    delete   bla  ;
}
