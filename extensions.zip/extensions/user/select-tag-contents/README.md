# Select Tag Contents
A <a href="https://github.com/adobe/brackets" target="_blank">Brackets</a> extension that provides a shortcut for selecting all content between tags in HTML, PHP, XML.

The idea for this came from this extension - <a href="https://github.com/sathyamoorthi/html-block-selector" target="_blank">github.com/sathyamoorthi/html-block-selector</a>

## Settings:
* Default shortcut is **Ctrl+Shift+A / Cmd+Shift+A**
  * **command-id** = "**select-tag-contents.select**"
  * see <a href="https://github.com/adobe/brackets/wiki/User-Key-Bindings" target="_blank">this</a> page for info on how to change shortcut
* "**select-tag-contents.includeTags**"
  * default - false
  * if true, tags are included in selection
* "**select-tag-contents.whenCursorOnTag**"
  * default - false
  * if true, will select all within tag that cursor is on
* "**select-tag-contents.inContextMenu**"
  * default - false
  * if true, the command will appear in context menu
