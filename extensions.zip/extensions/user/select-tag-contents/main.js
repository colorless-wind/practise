/*
The MIT License (MIT)

Copyright (c) 2015

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

/*jslint vars: true, plusplus: true, devel: true, nomen: true, regexp: true, indent: 4, maxerr: 50 */
/*global define, $, brackets, window */

/** Extension that selects all content within matching tags */
define(function (require, exports, module) {
    "use strict";

    var Menus              = brackets.getModule("command/Menus"),
        EditorManager      = brackets.getModule("editor/EditorManager"),
        CommandManager     = brackets.getModule("command/CommandManager"),
        KeyBindingManager  = brackets.getModule("command/KeyBindingManager"),
        PreferencesManager = brackets.getModule("preferences/PreferencesManager"),
        CodeMirrorModule   = brackets.getModule("thirdparty/CodeMirror/lib/codemirror"),

        STC_COMMAND_ID        = "select-tag-contents.select",
        DOC_TYPES             = ["html", "php", "xml"],
        SHORTCUT_KEYS         = "Ctrl-Shift-A",
        CONTEXT_MENU          = Menus.getContextMenu(Menus.ContextMenuIds.EDITOR_MENU),
        EXTENSION_PREFERENCES = PreferencesManager.getExtensionPrefs("select-tag-contents"),
        INCLUDE_TAGS,
        WHEN_CURSOR_ON_TAG,
        IN_CONTEXT_MENU,

        inMenu = false;

    // Define default perferences and preferences hint descriptions
    EXTENSION_PREFERENCES.definePreference("includeTags", "boolean", false, {
        type: "boolean",
        description: "true to include tags in the selection"
    });
    EXTENSION_PREFERENCES.definePreference("whenCursorOnTag", "boolean", false, {
        type: "boolean",
        description: "true to select all content within a tag if the cursor is on tag"
    });
    EXTENSION_PREFERENCES.definePreference("inContextMenu", "boolean", false, {
        type: "boolean",
        description: "true to have the command appear in context menu"
    });

    // Set preferences
    // includeTags:     true = include tags in selection
    // whenCursorOnTag: true = will select all within tag if cursor on tag
    // inContextMenu:   true = the command will appear in context menu
    INCLUDE_TAGS       = EXTENSION_PREFERENCES.get("includeTags");
    WHEN_CURSOR_ON_TAG = EXTENSION_PREFERENCES.get("whenCursorOnTag");
    IN_CONTEXT_MENU    = EXTENSION_PREFERENCES.get("inContextMenu");

    /**
     * Function that selects all content within matching tags
     */
    function selectTagsContents() {
        var editor = EditorManager.getActiveEditor(),
            doc = editor.document,
            language,
            cm,
            tags,
            openTag,
            closeTag,
            tag,
            tagLength,
            lineOpen,
            lineClose,
            prevLineClose,
            lineOpenIndex,
            lineCloseIndex,
            chOpenIndex,
            chCloseIndex,
            chAfterOpenIndex,
            chBeforeCloseIndex,
            chSelOpenIndex,
            chSelCloseIndex;

        if (editor && doc) {
            language = editor.document.getLanguage().getName().toLowerCase();

            // Check to see if language is supported
            if (DOC_TYPES.indexOf(language) !== -1) {
                cm = editor._codeMirror;

                if (WHEN_CURSOR_ON_TAG) {
                    tags = CodeMirrorModule.findMatchingTag(cm, editor.getCursorPos());
                } else {
                    tags = CodeMirrorModule.findEnclosingTag(cm, editor.getCursorPos());
                }

                if (tags && tags.open && tags.close) {
                    tagLength          = tags.open.tag.length;
                    lineOpenIndex      = tags.open.from.line;
                    lineCloseIndex     = tags.close.to.line;
                    chOpenIndex        = tags.open.from.ch;
                    chCloseIndex       = tags.close.to.ch;
                    lineOpen           = doc.getLine(lineOpenIndex);
                    lineClose          = doc.getLine(lineCloseIndex);
                    chAfterOpenIndex   = tags.open.to.ch;
                    chBeforeCloseIndex = tags.close.to.ch - tagLength - 3;

                    if (INCLUDE_TAGS) {
                        chSelOpenIndex  = chOpenIndex;
                        chSelCloseIndex = chCloseIndex;
                    } else {
                        chSelOpenIndex  = chAfterOpenIndex;
                        chSelCloseIndex = chBeforeCloseIndex;

                        // If there are no characters after the tag on the line, select next line
                        if (lineOpen.length === chAfterOpenIndex) {
                            lineOpenIndex++;
                            chSelOpenIndex = 0;
                        }

                        // If there are no characters before the tag on the line, select previous line
                        if (lineClose.substring(0, chBeforeCloseIndex).trim() === "") {
                            prevLineClose = doc.getLine(--lineCloseIndex);
                            chSelCloseIndex = prevLineClose.length;
                        }
                    }

                    // Perform selection
                    editor.setSelection({line: lineOpenIndex, ch: chSelOpenIndex},
                                        {line: lineCloseIndex, ch: chSelCloseIndex});
                }
            }
        }
    }

    // Register "Select Tag Contents" command and bind it to SHORTCUT_KEYS (default - Ctrl+Shift+A)
    CommandManager.register("Select Tag Contents", STC_COMMAND_ID, selectTagsContents);
    KeyBindingManager.addBinding(STC_COMMAND_ID, SHORTCUT_KEYS);

    // Preferences changed handler
    EXTENSION_PREFERENCES.on("change", function () {
        INCLUDE_TAGS       = EXTENSION_PREFERENCES.get("includeTags");
        WHEN_CURSOR_ON_TAG = EXTENSION_PREFERENCES.get("whenCursorOnTag");
        IN_CONTEXT_MENU    = EXTENSION_PREFERENCES.get("inContextMenu");

        // Add command if not already in context menu, if IN_CONTEXT_MENU preference is true
        // remove command from context menu, if IN_CONTEXT_MENU preference is false
        if (IN_CONTEXT_MENU) {
            if (!inMenu) {
                CONTEXT_MENU.addMenuItem(STC_COMMAND_ID);
                inMenu = true;
            }
        } else {
            CONTEXT_MENU.removeMenuItem(STC_COMMAND_ID);
            inMenu = false;
        }
    });
});
